<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010468ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Widget; use Pmpr\Module\Relation\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Post::symcgieuakksimmu(); } }
