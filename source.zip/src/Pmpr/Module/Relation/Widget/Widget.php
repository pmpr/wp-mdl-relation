<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bd2a28e4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Widget; use Pmpr\Module\Relation\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Post::ksyueceqagwomguk(); } }
