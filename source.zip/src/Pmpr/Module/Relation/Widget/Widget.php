<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dabb27c22f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Widget; use Pmpr\Module\Relation\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Post::symcgieuakksimmu(); } }
