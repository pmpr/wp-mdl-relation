<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870835abd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
