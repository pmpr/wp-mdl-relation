<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870835abd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\156\x5f\151\156\151\x74", [$this, "\145\156\161\x75\x65\165\x65"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->awgyqswkqywwmkye("\x72\145\154\x61\164\151\157\156", $eygsasmqycagyayw->get("\x69\x6e\144\x65\170\x2e\143\163\163")))->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\162\x65\x6c\141\164\x69\157\x6e", $eygsasmqycagyayw->get("\151\156\144\145\x78\x2e\x6a\x73"))->simswskycwagoeqy()->okawmmwsiuauwsiu(self::qiaqeaemuukkikmi))->ikqyiskqaaymscgw("\162\x65\x6c\x61\164\151\157\156", ["\x61\152\141\170" => Ajax::myikkigscysoykgy]); } }
