<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dabb27c22f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = self::akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x52\x65\154\x61\x74\x69\x6f\x6e", PR__MDL__RELATION); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\x52\x65\154\141\x74\151\x6f\x6e\40\x53\145\164\164\151\x6e\147", PR__MDL__RELATION)); } }
