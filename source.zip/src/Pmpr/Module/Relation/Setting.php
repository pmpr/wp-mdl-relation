<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870835abd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = self::akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x52\x65\x6c\141\164\x69\157\x6e", PR__MDL__RELATION); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\122\145\154\141\x74\x69\157\x6e\x20\123\x65\x74\164\x69\x6e\147", PR__MDL__RELATION)); } }
