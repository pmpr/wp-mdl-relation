<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b74ddda33             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function wyyuauosmqoeucmg() { $this->title = __("\x52\145\x6c\141\164\151\157\x6e", PR__MDL__RELATION); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x52\x65\154\141\164\x69\x6f\156\x20\123\145\164\x74\x69\156\147", PR__MDL__RELATION)); } }
