<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606995adaa37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = self::akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x52\145\x6c\x61\x74\x69\157\156", PR__MDL__RELATION); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\122\x65\154\141\164\151\x6f\x6e\40\x53\145\x74\164\x69\x6e\x67", PR__MDL__RELATION)); } }
