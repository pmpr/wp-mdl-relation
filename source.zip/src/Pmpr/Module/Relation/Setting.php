<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4245c3b91             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = self::akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x52\145\154\141\x74\151\157\x6e", PR__MDL__RELATION); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\122\x65\x6c\x61\x74\x69\x6f\x6e\40\x53\145\x74\x74\x69\156\x67", PR__MDL__RELATION)); } }
