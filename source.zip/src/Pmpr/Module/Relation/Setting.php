<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6692921c1f1a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = self::akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x52\x65\154\x61\164\x69\157\156", PR__MDL__RELATION); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\x52\145\x6c\x61\164\151\x6f\156\40\123\145\164\x74\x69\x6e\x67", PR__MDL__RELATION)); } }
