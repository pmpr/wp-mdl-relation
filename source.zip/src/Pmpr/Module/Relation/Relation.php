<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6692921c1f1a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Relation\Entity\Post; use Pmpr\Module\Relation\Widget\Widget; class Relation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\122\145\154\141\x74\x69\157\156", PR__MDL__RELATION); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto twkmiuomimomscew; } Setting::symcgieuakksimmu(); twkmiuomimomscew: Hook::symcgieuakksimmu(); Widget::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kooskuwkuayiuose; } Post::symcgieuakksimmu(); Asset::symcgieuakksimmu(); goto qwcegcuowwgiccos; kooskuwkuayiuose: Ajax::symcgieuakksimmu(); qwcegcuowwgiccos: } }
