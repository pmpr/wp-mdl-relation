<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606995adaa37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Relation\Entity\Post; use Pmpr\Module\Relation\Widget\Widget; class Relation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\122\x65\154\141\x74\x69\x6f\x6e", PR__MDL__RELATION); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto sycygoiaiqqageym; } Setting::symcgieuakksimmu(); sycygoiaiqqageym: Hook::symcgieuakksimmu(); Widget::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto gygawoqywkukmqee; } Post::symcgieuakksimmu(); Asset::symcgieuakksimmu(); goto kciouyuaqkyqomam; gygawoqywkukmqee: Ajax::symcgieuakksimmu(); kciouyuaqkyqomam: } }
