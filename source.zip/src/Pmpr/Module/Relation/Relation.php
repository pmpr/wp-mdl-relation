<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010468ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Relation\Entity\Post; use Pmpr\Module\Relation\Widget\Widget; class Relation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x52\x65\154\141\x74\x69\157\156", PR__MDL__RELATION); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto uqqaiagaeqgqgaiy; } Setting::symcgieuakksimmu(); uqqaiagaeqgqgaiy: Hook::symcgieuakksimmu(); Widget::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto esuiysskoweawsue; } Post::symcgieuakksimmu(); Asset::symcgieuakksimmu(); goto gaomwagkcciesyqy; esuiysskoweawsue: Ajax::symcgieuakksimmu(); gaomwagkcciesyqy: } }
