<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870835abd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Relation\Entity\Post; use Pmpr\Module\Relation\Widget\Widget; class Relation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x52\145\x6c\141\164\x69\157\x6e", PR__MDL__RELATION); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto uqqaiagaeqgqgaiy; } Setting::symcgieuakksimmu(); uqqaiagaeqgqgaiy: Hook::symcgieuakksimmu(); Widget::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto esuiysskoweawsue; } Post::symcgieuakksimmu(); Asset::symcgieuakksimmu(); goto gaomwagkcciesyqy; esuiysskoweawsue: Ajax::symcgieuakksimmu(); gaomwagkcciesyqy: } }
