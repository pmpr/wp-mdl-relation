<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae926dfd6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { public function ckgmycmaukqgkosk() { $quowyokcwswmuois = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($quowyokcwswmuois)->myysgyqcumekoueo(); parent::ckgmycmaukqgkosk(); } }
