<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8a8d8657             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Record extends Common { const kuuiowmkimmuywsm = "\x72\x65\x6c\x61\x74\151\157\x6e\x5f\x49\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::emuwacasoaaageiq)->guiaswksukmgageq(__("\x52\x65\x63\157\162\144", PR__MDL__RELATION))->muuwuqssqkaieqge(__("\122\x65\x63\157\x72\144\163", PR__MDL__RELATION)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::igecewwoemccgwsq)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\117\x72\151\x67\x69\x6e", PR__MDL__RATING)))->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::gygsikewooaciecc)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\x44\145\x73\164\x69\156\141\x74\x69\157\x6e", PR__MDL__RATING)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kuuiowmkimmuywsm)->uwmyqckcyamwaiww(Relation::class)->wuuqgaekqeymecag()->gswweykyogmsyawy(__("\x52\145\x6c\141\164\x69\x6f\x6e", PR__MDL__RATING))); parent::ewaqwooqoqmcoomi(); } }
