<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606995adaa37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Record extends Common { const kuuiowmkimmuywsm = "\162\x65\x6c\141\x74\x69\x6f\x6e\137\111\144"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::emuwacasoaaageiq)->guiaswksukmgageq(__("\122\145\x63\157\162\x64", PR__MDL__RELATION))->muuwuqssqkaieqge(__("\x52\145\143\x6f\162\x64\x73", PR__MDL__RELATION)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::igecewwoemccgwsq)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\117\162\x69\x67\x69\156", PR__MDL__RATING)))->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::gygsikewooaciecc)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\x44\x65\x73\164\x69\x6e\x61\164\x69\157\x6e", PR__MDL__RATING)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kuuiowmkimmuywsm)->uwmyqckcyamwaiww(Relation::class)->wuuqgaekqeymecag()->gswweykyogmsyawy(__("\122\x65\154\x61\x74\x69\157\156", PR__MDL__RATING))); parent::ewaqwooqoqmcoomi(); } }
