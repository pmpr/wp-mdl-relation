<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4245c3b91             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Record extends Common { const kuuiowmkimmuywsm = "\x72\x65\154\x61\164\x69\x6f\x6e\x5f\111\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::emuwacasoaaageiq)->guiaswksukmgageq(__("\x52\145\x63\157\x72\144", PR__MDL__RELATION))->muuwuqssqkaieqge(__("\122\x65\143\157\162\144\163", PR__MDL__RELATION)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::igecewwoemccgwsq)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\117\x72\x69\147\x69\156", PR__MDL__RATING)))->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::gygsikewooaciecc)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\104\x65\163\164\151\156\x61\164\151\x6f\156", PR__MDL__RATING)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kuuiowmkimmuywsm)->uwmyqckcyamwaiww(Relation::class)->wuuqgaekqeymecag()->gswweykyogmsyawy(__("\122\x65\154\x61\164\x69\x6f\x6e", PR__MDL__RATING))); parent::ewaqwooqoqmcoomi(); } }
