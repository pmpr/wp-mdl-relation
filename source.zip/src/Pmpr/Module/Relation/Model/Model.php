<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606995adaa37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Module\Relation\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Relation::symcgieuakksimmu(); Record::symcgieuakksimmu(); } }
