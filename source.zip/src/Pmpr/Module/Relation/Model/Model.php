<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6692921c1f1a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Module\Relation\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Relation::symcgieuakksimmu(); Record::symcgieuakksimmu(); } }
