<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010468ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Module\Relation\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Relation::symcgieuakksimmu(); Record::symcgieuakksimmu(); } }
