<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4245c3b91             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Model; use Pmpr\Module\Relation\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Relation::symcgieuakksimmu(); Record::symcgieuakksimmu(); } }
