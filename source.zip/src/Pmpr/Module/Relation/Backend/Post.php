<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dabb27c22f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; class Post extends Common { }
