<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6692921c1f1a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; class Post extends Common { }
