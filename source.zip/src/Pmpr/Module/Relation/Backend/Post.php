<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bd2a28e4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; class Post extends Common { }
