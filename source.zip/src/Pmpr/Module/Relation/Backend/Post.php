<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11b220dd6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; class Post extends Common { }
