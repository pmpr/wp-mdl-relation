<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684010468ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; class Post extends Common { }
