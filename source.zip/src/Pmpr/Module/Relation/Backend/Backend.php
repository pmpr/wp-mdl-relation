<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b74ddda33             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Relation\Backend; use Pmpr\Module\Relation\Container; class Backend extends Container { }
